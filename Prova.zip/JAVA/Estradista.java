/*Pablo Carvalho Baldiviezo
 * 29/08/23
 */

public class Estradista extends Pessoa implements Ciclista {

    @Override
    public void Pedalar() {
        System.out.println(getNome()+" pedala em estradas...");
    }
    
}
