/*Pablo Carvalho Baldiviezo
 * 29/08/23
 */

public class Maratonista extends Pessoa implements Corredor{
    @Override
    public void correr() {
        System.out.println(getNome()+" começou a correr...");
    }

}