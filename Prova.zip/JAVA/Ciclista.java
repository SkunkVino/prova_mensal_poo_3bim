/*Pablo Carvalho Baldiviezo
 * 29/08/23
 */

public interface Ciclista{
    public void Pedalar();
}