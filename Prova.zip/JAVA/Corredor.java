/*Pablo Carvalho Baldiviezo
 * 29/08/23
 */
public interface Corredor {
    
    public  void correr();

}
